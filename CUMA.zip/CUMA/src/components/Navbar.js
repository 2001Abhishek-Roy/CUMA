import React from "react";
import { Link } from "react-router-dom";
import { FaHome, FaInfoCircle, FaUserPlus, FaSignInAlt } from "react-icons/fa"; // Import required icons
import "./Navbar.css"; // Ensure this file contains your Navbar-specific styles

function Navbar() {
  return (
    <nav className="navbar">
      <h1 className="logo">Christ University AI Multilingual Assistant</h1>
      <ul className="nav-links">
        <li>
          <Link to="/">
            <FaHome className="nav-icon" /> Home
          </Link>
        </li>
        <li>
          <Link to="/about">
            <FaInfoCircle className="nav-icon" /> About Us
          </Link>
        </li>
        <li>
          <Link to="/signup">
            <FaUserPlus className="nav-icon" /> Sign Up
          </Link>
        </li>
        <li>
          <Link to="/login">
            <FaSignInAlt className="nav-icon" /> Login
          </Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
