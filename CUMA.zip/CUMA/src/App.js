import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import AboutUsPage from "./pages/AboutUsPage";
import SignUpPage from "./pages/SignUpPage";
import LoginPage from "./pages/LoginPage";
import MainPage from "./pages/MainPage";
import Navbar from "./components/Navbar";
import AdminLoginPage from "./pages/AdminLoginPage";
import FacultyLoginPage from "./pages/FacultyLoginPage";
import StudentLoginPage from "./pages/StudentLoginPage";
import TermsPage from "./pages/TermsPage";  
import StudentSignUpPage from "./pages/StudentSignUpPage";  
import FacultySignUpPage from "./pages/FacultySignUpPage";  
import ForgotPasswordPage from "./pages/ForgotPasswordPage";  // Added Forgot Password Page

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutUsPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/signup/student" element={<StudentSignUpPage />} />
        <Route path="/signup/faculty" element={<FacultySignUpPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/main" element={<MainPage />} />
        <Route path="/admin-login" element={<AdminLoginPage />} />
        <Route path="/faculty-login" element={<FacultyLoginPage />} />
        <Route path="/student-login" element={<StudentLoginPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} /> {/* Added Forgot Password Route */}
      </Routes>
    </Router>
  );
}

export default App;
