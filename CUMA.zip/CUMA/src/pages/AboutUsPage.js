import React from "react";
import "./AboutUsPage.css";
import { FaBullseye, FaLightbulb, FaUserTie } from "react-icons/fa";

function AboutUsPage() {
  return (
    <div className="about">
      {/* Hero Section */}
      <section className="about-hero">
        <div className="hero-content">
          <h1>About Us</h1>
          <p>
            Welcome to the Christ University Multilingual Assistant! We’re
            dedicated to breaking language barriers and connecting people
            globally.
          </p>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="mission-vision">
        <div className="card mission">
          <FaBullseye className="card-icon" />
          <h2>Our Mission</h2>
          <p>
            To enable seamless communication across diverse languages,
            fostering a global learning environment.
          </p>
        </div>
        <div className="card vision">
          <FaLightbulb className="card-icon" />
          <h2>Our Vision</h2>
          <p>
            To become the leading multilingual assistant for academic and
            cultural exchange worldwide.
          </p>
        </div>
      </section>

      {/* Team Section */}
      <section className="team">
        <h2>Meet Our Team</h2>
        <div className="team-container">
          <div className="team-card">
          <img
          src={require("./M1.jpg")}
          alt="Abhishek Pandey"
          className="team-img"
          />

            <h3>Abhishek Pandey</h3>
            <p>Backend Developer</p>
          </div>
          <div className="team-card">
            <img
              src="https://via.placeholder.com/150"
              alt="Abhishek Roy"
              className="team-img"
            />
            <h3>Abhishek Roy</h3>
            <p>UI/UX Designer</p>
          </div>
          
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="cta">
        <h2>Join Us on Our Journey</h2>
        <p>
          Discover how the Christ University Multilingual Assistant can
          transform your academic and communication experience.
        </p>
      </section>
    </div>
  );
}

export default AboutUsPage;
