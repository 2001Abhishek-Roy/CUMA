import React from "react";

function LandingPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>About the Multilingual Assistant</h1>
      <p>
        The Christ University Multilingual Assistant is designed to help students and faculty communicate across languages effectively.
      </p>
    </div>
  );
}

export default LandingPage;
