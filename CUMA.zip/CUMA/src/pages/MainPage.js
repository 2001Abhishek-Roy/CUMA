import React from "react";

function MainPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Main Application</h1>
      <p>Interact with the multilingual assistant here!</p>
    </div>
  );
}

export default MainPage;
