import React, { useState } from "react";
import { FaUser, FaEnvelope, FaLock, FaBuilding } from "react-icons/fa";
import { motion } from "framer-motion";
import "./FacultySignUpPage.css";

function FacultySignUpPage() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    department: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const { fullName, email, password, department } = formData;

    if (!fullName) return "Full Name is required!";
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Invalid Email Address!";
    if (!password || password.length < 8) return "Password must be at least 8 characters!";
    if (!department) return "Department is required!";
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      setSuccess(false);
    } else {
      setError("");
      setSuccess(true);
    }
  };

  return (
    <motion.div
      className="faculty-signup-page"
      initial={{ x: "100vw" }}
      animate={{ x: 0 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
    >
      <div className="signup-container">
        <h1>Faculty Sign Up</h1>
        <form onSubmit={handleSubmit}>
          {/* Full Name */}
          <div className="input-group">
            <FaUser className="input-icon" />
            <input
              type="text"
              name="fullName"
              placeholder="Full Name"
              value={formData.fullName}
              onChange={handleInputChange}
            />
          </div>

          {/* Email */}
          <div className="input-group">
            <FaEnvelope className="input-icon" />
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>

          {/* Password */}
          <div className="input-group">
            <FaLock className="input-icon" />
            <input
              type="password"
              name="password"
              placeholder="Password (min. 8 characters)"
              value={formData.password}
              onChange={handleInputChange}
            />
          </div>

          {/* Department */}
          <div className="input-group">
            <FaBuilding className="input-icon" />
            <input
              type="text"
              name="department"
              placeholder="Department"
              value={formData.department}
              onChange={handleInputChange}
            />
          </div>

          {/* Submit Button */}
          <button type="submit" className="signup-btn">
            Sign Up
          </button>
        </form>

        <div className="login-redirect">
      <p>Already have an account? 
        <a href="/login" className="login-link">
      <FaLock /> Login here
    </a>
  </p>
</div>


        {/* Error Modal */}
        {error && (
          <motion.div
            className="error-modal"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
          >
            <p>{error}</p>
          </motion.div>
        )}

        {/* Success Modal */}
        {success && (
          <motion.div
            className="success-modal"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h2>Sign-Up Successful!</h2>
            <p>You have successfully signed up as faculty.</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

export default FacultySignUpPage;
