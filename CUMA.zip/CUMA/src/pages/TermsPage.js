import React, { useState } from "react";
import "./TermsPage.css";
import { FaCheckCircle, FaRegWindowClose } from "react-icons/fa";

function TermsPage() {
  const [showModal, setShowModal] = useState(false);

  const toggleModal = () => {
    setShowModal(!showModal);
  };

  return (
    <div className="terms-page">
      <div className="terms-container">
        <h1>Terms and Conditions</h1>
        <p>
          Welcome to Christ University Multilingual Assistant. Please read the
          following terms and conditions carefully.
        </p>

        <button className="view-terms-btn" onClick={toggleModal}>
          View Full Terms & Conditions
        </button>

        {/* Modal */}
        {showModal && (
          <div className="modal-container">
            <div className="modal animated-modal">
              <button className="close-modal-btn" onClick={toggleModal}>
                <FaRegWindowClose />
              </button>
              <div className="modal-content">
                <h2>Full Terms & Conditions</h2>
                <p>
                  By using this service, you agree to the following terms and
                  conditions:
                </p>
                <ul>
                  <li>Use of the service is at your own risk.</li>
                  <li>We are not responsible for any content provided by users.</li>
                  <li>Your personal information will be kept confidential.</li>
                  <li>Any misuse of the platform will result in termination of your account.</li>
                  <li>We reserve the right to modify these terms at any time.</li>
                </ul>
                <button className="accept-btn">
                  <FaCheckCircle /> Accept
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default TermsPage;
