import React from "react";
import "./LoginPage.css";
import { FaUserTie, FaChalkboardTeacher, FaUserGraduate } from "react-icons/fa";
import { Link } from "react-router-dom";

function LoginPage() {
  return (
    <div className="login-page">
      <div className="login-container">
        <h1>Login</h1>
        <p>Select your role to log in:</p>
        <div className="role-buttons">
          {/* Admin Login */}
          <Link to="/admin-login" className="role-btn admin-btn">
            <FaUserTie className="role-icon" /> Admin
          </Link>

          {/* Faculty Login */}
          <Link to="/faculty-login" className="role-btn faculty-btn">
            <FaChalkboardTeacher className="role-icon" /> Faculty
          </Link>

          {/* Student Login */}
          <Link to="/student-login" className="role-btn student-btn">
            <FaUserGraduate className="role-icon" /> Student
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
