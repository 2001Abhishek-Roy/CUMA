import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { FaUser, FaChalkboardTeacher } from "react-icons/fa"; // Importing icons
import "./SignUpPage.css";

function SignUpPage() {
  return (
    <div className="signup-page">
      <motion.div
        className="signup-container"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <h1>Choose Your Role</h1>
        <p>Join the Christ University Multilingual Assistant Community now!</p>
        <div className="role-selection">
          <Link to="/signup/student" className="role-btn student-btn">
            <FaUser className="role-icon" /> Sign Up as Student
          </Link>
          <Link to="/signup/faculty" className="role-btn faculty-btn">
            <FaChalkboardTeacher className="role-icon" /> Sign Up as Faculty
          </Link>
        </div>
      </motion.div>
    </div>
  );
}

export default SignUpPage;
