import React, { useState } from "react";
import "./ForgotPasswordPage.css";
import { FaEnvelope, FaCheckCircle } from "react-icons/fa";

function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simulate sending reset link
    if (email) {
      setShowSuccessPopup(true);
    }
  };

  const closePopup = () => {
    setShowSuccessPopup(false);
  };

  return (
    <div className="forgot-password-page">
      <div className="forgot-password-container animated-container">
        <h1>Forgot Password</h1>
        <p>Enter your email address to receive a password reset link.</p>
        <form className="forgot-password-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <FaEnvelope className="input-icon" />
            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="reset-btn">
            Send Reset Link
          </button>
        </form>
      </div>

      {/* Success Popup */}
      {showSuccessPopup && (
        <div className="popup success-popup animated-popup">
          <FaCheckCircle className="popup-icon success-icon" />
          <h2>Reset Link Sent!</h2>
          <p>We've sent a password reset link to your email address.</p>
          <button className="close-btn" onClick={closePopup}>
            Close
          </button>
        </div>
      )}
    </div>
  );
}

export default ForgotPasswordPage;
