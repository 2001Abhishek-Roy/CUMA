import React from "react";
import "./FacultyLoginPage.css";
import { FaEnvelope, FaLock, FaKey } from "react-icons/fa"; // Import FaKey

function FacultyLoginPage() {
  return (
    <div className="faculty-login-page">
      <div className="login-container">
        <h1>Faculty Login</h1>
        <form className="login-form">
          <div className="input-group">
            <FaEnvelope className="input-icon" />
            <input type="email" placeholder="Faculty Email" required />
          </div>
          <div className="input-group">
            <FaLock className="input-icon" />
            <input type="password" placeholder="Password" required />
          </div>
          <button type="submit" className="login-btn">Login</button>
        </form>

        {/* Forgot Password Link */}
        <div className="forgot-password">
          <a href="/forgot-password" className="forgot-password-link">
            <FaKey className="forgot-password-icon" /> Forgot Password?
          </a>
        </div>
      </div>
    </div>
  );
}

export default FacultyLoginPage;
