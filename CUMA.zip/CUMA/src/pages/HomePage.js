import React from "react";
import "./HomePage.css";
import { Link } from "react-router-dom";

// Optional: Import icons from a library like react-icons
import { FaComments, FaBook, FaUserGraduate } from "react-icons/fa";

function HomePage() {
  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>Welcome to Christ University Multilingual Assistant</h1>
          <p>Connecting students and faculty across languages effortlessly.</p>
          <Link to="/signup" className="cta-btn">
            Get Started
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="features">
        <h2>Our Features</h2>
        <div className="features-container">
          <div className="feature-card">
            <FaComments className="feature-icon" />
            <h3>Multilingual Chat</h3>
            <p>Communicate seamlessly in multiple languages with our smart assistant.</p>
          </div>
          <div className="feature-card">
            <FaBook className="feature-icon" />
            <h3>Language Learning</h3>
            <p>Enhance your language skills with interactive tools and resources.</p>
          </div>
          <div className="feature-card">
            <FaUserGraduate className="feature-icon" />
            <h3>Academic Support</h3>
            <p>Receive help with research, translations, and language-based queries.</p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials">
        <h2>What Our Users Say</h2>
        <div className="testimonial-container">
          <div className="testimonial">
            <p>"The multilingual assistant has transformed our communication!"</p>
            <h4>- Aisha Khan, Student</h4>
          </div>
          <div className="testimonial">
            <p>"A fantastic tool for bridging language gaps in academia."</p>
            <h4>- Dr. Rajesh Pillai, Professor</h4>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="footer">
        <p>© 2025 Christ University. All rights reserved.</p>
        <div className="footer-links">
          <a href="/contact">Contact Us</a>
          <a href="/privacy">Privacy Policy</a>
          <a href="/terms">Terms of Service</a>
        </div>
      </footer>
    </div>
  );
}

export default HomePage;
